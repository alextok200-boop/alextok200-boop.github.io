# Web UI Design Patterns 技能

## 安装

本技能已安装至 `~/.workbuddy/skills/web-ui-design-patterns/`

## 文件结构

```
web-ui-design-patterns/
├── SKILL.md                          # 技能定义
├── css/
│   └── patterns.css                  # CSS 组件库（800+ 行）
├── index.html                        # 交互式 Demo 页面
├── scripts/
│   ├── generate_css.py               # CSS 生成脚本
│   ├── generate_demo.py              # Demo 页面生成脚本
│   └── generate_docs.py              # 参考文档生成脚本
└── references/
    └── patterns.md                   # 模式参考文档
```

## 7 种设计模式

| 模式 | 核心效果 | CSS 特性 |
|------|---------|---------|
| 留白 | 呼吸感排版 | CSS 变量间距系统 |
| 栅格 | 12列自适应 | CSS Grid + 响应式断点 |
| 卡片微交互 | Hover 上升+阴影 | Transform + Transition |
| 瀑布流 | 多列不等高 | CSS Columns + Break |
| 液态玻璃 | 毛玻璃+折射 | Backdrop-filter |
| 骨架屏 | 脉冲动画占位 | Keyframes + Gradient |
| 空状态 | 插画+CTA引导 | Flexbox + SVG |

## 使用方式

1. **直接打开 Demo**：双击 `index.html` 查看效果
2. **复制 CSS**：将 `css/patterns.css` 复制到项目
3. **参考文档**：阅读 `references/patterns.md` 了解用法

## 自定义

修改 `:root` 中的 CSS 变量即可定制主题：
- `--pattern-primary`：主色调
- `--pattern-bg`：背景色
- `--pattern-text`：文字色
- `--pattern-space-*`：间距系统
