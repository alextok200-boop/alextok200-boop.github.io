"""
生成 Web UI Design Patterns 参考文档
输出：references/patterns.md
"""
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
OUTPUT_MD = SKILL_DIR / "references" / "patterns.md"
OUTPUT_MD.parent.mkdir(parents=True, exist_ok=True)

MD_CONTENT = '''# Web UI Design Patterns 参考文档

## 概述

本文档详细说明 7 种现代前端设计模式的核心原理、使用方法和最佳实践。

---

## 1. 留白系统（Whitespace）

### 核心原理
留白不是"空"，而是**视觉呼吸空间**。通过标准化的间距系统，控制元素的视觉层级和阅读节奏。

### 设计 Token
```css
--pattern-space-xs: 0.5rem;   /* 8px */
--pattern-space-sm: 1rem;     /* 16px */
--pattern-space-md: 1.5rem;   /* 24px */
--pattern-space-lg: 2rem;     /* 32px */
--pattern-space-xl: 3rem;     /* 48px */
--pattern-space-2xl: 4rem;    /* 64px */
--pattern-space-3xl: 6rem;    /* 96px */
```

### 使用场景
- **内容型页面**：博客、文章、知识库
- **品牌首页**：强调产品亮点，减少信息密度
- **数据看板**：区分不同数据区块

### 使用示例
```html
<!-- 垂直间距 -->
<div class="pattern-my-xl">上下间距 48px</div>

<!-- 水平间距 -->
<div class="pattern-px-lg">左右间距 32px</div>

<!-- 组合使用 -->
<div class="pattern-py-2xl pattern-px-xl">全包围间距</div>
```

### 最佳实践
1. **保持一致性**：同一层级元素使用相同间距
2. **呼吸感优先**：标题下方留白 ≥ 段落上方
3. **移动端收紧**：小屏幕适当缩小间距倍率

---

## 2. 栅格系统（Grid）

### 核心原理
**12列栅格**是网页布局的行业标准。12 可以被子 1、2、3、4、6 整除，提供最大的灵活性。

### 设计 Token
```css
/* 断点 */
sm: 640px   /* 手机横屏 */
md: 768px   /* 平板 */
lg: 1024px  /* 笔记本 */
xl: 1280px  /* 桌面 */
```

### 使用场景
- **列表页**：商品列表、文章列表、团队展示
- **仪表盘**：数据面板、统计卡片
- **营销页**：功能展示、客户评价

### 使用示例
```html
<!-- 12列栅格 -->
<div class="pattern-grid pattern-grid-cols-12">
  <div class="pattern-col-span-12">全宽</div>
  <div class="pattern-col-span-6">半宽</div>
  <div class="pattern-col-span-6">半宽</div>
  <div class="pattern-col-span-4">三分之一</div>
  <div class="pattern-col-span-4">三分之一</div>
  <div class="pattern-col-span-4">三分之一</div>
</div>

<!-- 响应式 -->
<div class="pattern-grid pattern-grid-cols-12">
  <div class="pattern-col-span-12 pattern-md:col-span-6 pattern-lg:col-span-3">
    响应式列
  </div>
</div>
```

### 最佳实践
1. **优先使用 12 列**：不要强行使用其他列数
2. **断点从下往上**：先写移动端，再逐步增强
3. **gap 控制间距**：不要依赖 margin

---

## 3. 卡片微交互（Card + Micro）

### 核心原理
**微交互**是用户与界面互动的细节反馈。卡片的 hover 状态通过位移、阴影、颜色变化传递"可点击"信号。

### 设计 Token
```css
/* 阴影层级 */
--pattern-shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
--pattern-shadow-md: 0 4px 6px -1px rgba(0,0,0,0.4);
--pattern-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.5);
--pattern-shadow-xl: 0 20px 25px -5px rgba(0,0,0,0.6);

/* 动画时间 */
--pattern-transition-fast: 150ms;
--pattern-transition-base: 300ms;
--pattern-transition-slow: 500ms;
```

### 使用场景
- **产品卡片**：电商商品、应用展示
- **作者卡片**：团队介绍、创作者信息
- **数据卡片**：统计指标、关键数字

### 使用示例
```html
<div class="pattern-card pattern-card--interactive">
  <div class="pattern-card__media">
    <img src="image.jpg" alt="产品图片">
  </div>
  <div class="pattern-card__body">
    <h3 class="pattern-card__title">卡片标题</h3>
    <p class="pattern-card__desc">卡片描述文字</p>
  </div>
  <div class="pattern-card__footer">
    <button class="pattern-btn">查看详情</button>
  </div>
</div>
```

### 最佳实践
1. **Y轴位移 ≤ 4px**：过大位移会造成视觉跳跃
2. **阴影扩散 ≤ 20px**：保持层次感，避免沉重
3. **图片缩放 ≤ 1.05x**：微妙放大即可，过度夸张

---

## 4. 瀑布流布局（Masonry）

### 核心原理
**瀑布流**通过多列不等高布局，充分利用垂直空间，适用于内容长度不一的场景。

### 两种实现方式

#### CSS Column 方式（推荐）
```css
.masonry {
  column-count: 3;
  column-gap: 24px;
}

.masonry-item {
  break-inside: avoid;
  margin-bottom: 24px;
}
```

#### JS 方式（精确控制）
```javascript
// 等待图片加载完成后重新计算布局
const masonry = new Masonry('.masonry', {
  itemSelector: '.masonry-item',
  columnWidth: 280,
  gutter: 24
});
```

### 使用场景
- **图片库**：摄影作品、素材库
- **作品集**：设计师 portfolio
- **Feed 流**：社交动态、新闻列表

### 最佳实践
1. **最小宽度 280px**：保证内容可读性
2. **列数响应式**：移动端 1 列，平板 2 列，桌面 3 列
3. **图片懒加载**：配合 `loading="lazy"` 优化性能

---

## 5. 液态玻璃（Liquid Glass）

### 核心原理
**毛玻璃效果**通过 `backdrop-filter: blur()` 实现背景模糊，配合半透明渐变和光晕，营造未来感玻璃质感。

### 设计 Token
```css
/* 玻璃基础 */
--pattern-glass-bg: rgba(255, 255, 255, 0.05);
--pattern-glass-border: rgba(255, 255, 255, 0.1);
--pattern-glass-blur: 20px;
--pattern-glass-highlight: rgba(255, 255, 255, 0.1);

/* 增强版（导航栏） */
backdrop-filter: blur(24px) saturate(180%);
-webkit-backdrop-filter: blur(24px) saturate(180%);
```

### 使用场景
- **导航栏**：滚动时保持内容可见性
- **弹窗/对话框**：背景模糊聚焦内容
- **悬浮层**：Tooltip、Dropdown

### 使用示例
```html
<!-- 玻璃卡片 -->
<div class="pattern-glass">
  <h3>玻璃卡片标题</h3>
  <p>半透明背景 + 模糊效果</p>
</div>

<!-- 导航栏 -->
<nav class="pattern-glass--nav">
  <div class="container">导航内容</div>
</nav>

<!-- 弹窗 -->
<div class="pattern-glass--modal">
  <div class="pattern-glass--modal-content">
    弹窗内容
  </div>
</div>
```

### 最佳实践
1. **iOS 18 风格**：blur 24px + saturate 180%
2. **暗色主题优先**：玻璃效果在深色背景更明显
3. **Fallback 处理**：不支持 backdrop-filter 的设备降级为半透明背景

---

## 6. 骨架屏（Skeleton）

### 核心原理
**骨架屏**在数据加载期间显示占位元素，通过脉冲动画引导用户视线，减少等待焦虑。

### 设计 Token
```css
@keyframes skeleton-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

.pattern-skeleton {
  background: linear-gradient(
    90deg,
    var(--pattern-surface-elevated) 25%,
    var(--pattern-bg-alt) 50%,
    var(--pattern-surface-elevated) 75%
  );
  background-size: 200% 100%;
  animation: skeleton-pulse 1.5s ease-in-out infinite;
}
```

### 使用场景
- **数据加载**：列表、详情、仪表盘
- **异步渲染**：SPA 页面过渡
- **首屏优化**：FCP 前展示结构

### 使用示例
```html
<!-- 卡片骨架 -->
<div class="pattern-skeleton pattern-skeleton--card">
  <div class="pattern-skeleton pattern-skeleton--circle"></div>
  <div class="pattern-skeleton pattern-skeleton--text"></div>
  <div class="pattern-skeleton pattern-skeleton--text"></div>
  <div class="pattern-skeleton pattern-skeleton--text" style="width: 60%"></div>
</div>

<!-- 列表骨架 -->
<div class="pattern-skeleton pattern-skeleton--text"></div>
<div class="pattern-skeleton pattern-skeleton--text"></div>
<div class="pattern-skeleton pattern-skeleton--text"></div>
```

### 最佳实践
1. **动画时长 1.5s**：不宜过快（刺眼）或过慢（拖沓）
2. **渐变方向水平**：从左到右的扫描感更自然
3. **及时替换**：数据就绪后立即显示真实内容

---

## 7. 空状态（Empty State）

### 核心原理
**空状态**是用户面对空白页面时的引导设计，通过插画 + 文案 + CTA 降低困惑，提升转化率。

### 设计要素
1. **插画**：弱化存在感（opacity 0.5-0.6）
2. **标题**：说明当前状态
3. **描述**：解释原因和行动指引
4. **CTA**：主要操作按钮

### 使用场景
- **首次使用**：新用户引导
- **搜索无结果**：提供替代方案
- **操作失败**：错误后的恢复路径

### 使用示例
```html
<div class="pattern-empty">
  <div class="pattern-empty__illustration">
    <!-- SVG 插画 -->
  </div>
  <h3 class="pattern-empty__title">暂无内容</h3>
  <p class="pattern-empty__desc">这里还没有任何数据，点击下方按钮开始创建。</p>
  <div class="pattern-empty__actions">
    <button class="pattern-btn pattern-btn--primary">创建新项目</button>
    <button class="pattern-btn">查看详情</button>
  </div>
</div>
```

### 最佳实践
1. **CTA 唯一**：最多一个主按钮，避免选择困难
2. **幽默文案**：适当增加亲和力（视品牌调性）
3. **路径引导**：提供返回、重新操作等选项

---

## 快速开始

### 引入组件库
```html
<link rel="stylesheet" href="css/patterns.css">
```

### 使用设计 Token
```css
:root {
  --pattern-primary: #6366f1;
  --pattern-space-lg: 2rem;
  /* ... */
}
```

### 组合使用
```html
<div class="pattern-grid pattern-grid-cols-12 pattern-space-xl">
  <div class="pattern-col-span-12 pattern-md:col-span-6">
    <div class="pattern-card pattern-glow">
      <!-- 内容 -->
    </div>
  </div>
</div>
```

---

## 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|---------|
| v1.0.0 | 2026-09-09 | 初版发布，包含 7 种设计模式 |
'''

OUTPUT_MD.write_text(MD_CONTENT, encoding="utf-8")
print(f"✅ 参考文档已生成：{OUTPUT_MD}")
print(f"   文件大小：{OUTPUT_MD.stat().st_size} bytes")
