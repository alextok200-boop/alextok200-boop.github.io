---
name: web-ui-design-patterns
description: 将 7 种现代前端设计模式（留白/Whitespace、栅格/Grid、卡片微交互/Card+Micro、瀑布流/Masonry、液态玻璃/Liquid Glass、骨架屏/Skeleton、空状态/Empty State）沉淀为可复用的 CSS 组件库 + 文档，并输出完整的 HTML demo 页面。触发词：UI 设计模式、设计系统、组件库、前端设计、CSS 模式、网页设计、留白、栅格、卡片、瀑布流、液态玻璃、骨架屏、空状态。
version: 1.0.0
author: KONLLEN AI
agent_created: true
keywords: [web, ui, design, patterns, css, components, frontend]
triggers:
  - "把这套设计模式做成 CSS 组件库"
  - "生成现代前端 UI 设计模式文档"
  - "沉淀网页设计模式"
  - "输出留白栅格卡片微交互等 7 种模式"
  - "生成 Liquid Glass 液态玻璃效果"
  - "做一版 Skeleton 骨架屏 demo"
  - "Empty State 空状态组件"
---

# Web UI Design Patterns 技能

## 核心设计理念

本技能将 7 种经过业界验证的现代前端设计模式沉淀为：
1. **CSS 组件库** (`css/patterns.css`) — 零依赖、纯 CSS + 少量 JS
2. **HTML Demo 页面** (`index.html`) — 可交互的可视化文档
3. **使用指南** (`references/patterns.md`) — 每个模式的原理、使用场景、API

## 7 种设计模式

| # | 模式名称 | 英文 | 核心效果 | 适用场景 |
|---|---------|------|---------|---------|
| 1 | 留白 | Whitespace | 呼吸感排版、视觉层级 | 内容型页面、品牌页 |
| 2 | 栅格 | Grid | 12列自适应、响应式断点 | 列表页、仪表盘、营销页 |
| 3 | 卡片微交互 | Card+Micro | hover 上升 + shadow + scale | 产品卡、作者卡、数据卡 |
| 4 | 瀑布流 | Masonry | 多列不等高、自动填充 | 图片库、作品集、Feed |
| 5 | 液态玻璃 | Liquid Glass | 毛玻璃 + 折射 + 光晕 | 导航栏、弹窗、悬浮层 |
| 6 | 骨架屏 | Skeleton | 脉冲动画占位 | 数据加载、异步渲染 |
| 7 | 空状态 | Empty State | 插画 + 引导 CTA | 无数据、首次使用 |

## 文件结构

```
web-ui-design-patterns/
├── SKILL.md                          # 本文件
├── css/
│   └── patterns.css                  # 全部 CSS 组件（~800行）
├── index.html                        # 交互式 Demo 页面
├── scripts/
│   └── masonry.js                    # 瀑布流布局逻辑
└── references/
    └── patterns.md                   # 模式参考文档
```

## 生成流程

### 第一步：生成 CSS 组件库

```bash
python scripts/generate_css.py
```

输出 `css/patterns.css`，包含：
- `whitespace/` — 间距系统（8px 基准 × 倍数）
- `grid/` — 12列栅格 + 响应式断点
- `card-micro/` — 卡片 hover/focus/active 状态
- `masonry/` — 多列瀑布流布局
- `liquid-glass/` — backdrop-filter + 光晕 + 折射
- `skeleton/` — 脉冲动画 + 主题适配
- `empty-state/` — 插画 SVG + CTA 按钮

### 第二步：生成 Demo 页面

```bash
python scripts/generate_demo.py
```

输出 `index.html`，包含：
- 顶部导航（Liquid Glass 效果）
- 左侧模式选择器
- 右侧实时预览区
- 每个模式的可交互 Demo

### 第三步：输出参考文档

```bash
python scripts/generate_docs.py
```

输出 `references/patterns.md`，包含：
- 每个模式的原理说明
- CSS 变量配置方式
- 使用示例代码
- 性能注意事项

## 使用方式

用户调用此技能时，应：
1. **询问需求**：确定要生成的页面类型（营销页/仪表盘/作品集等）
2. **选择模式**：让用户勾选需要的模式（默认全选）
3. **生成代码**：运行上述三步脚本
4. **输出结果**：用 `present_files` 展示生成的 HTML/CSS

## CSS 变量接口

所有模式共用一套设计 token：

```css
:root {
  /* 色彩 */
  --pattern-primary: #6366f1;
  --pattern-secondary: #ec4899;
  --pattern-bg: #0f172a;
  --pattern-surface: #1e293b;
  --pattern-text: #f8fafc;
  --pattern-text-muted: #94a3b8;
  --pattern-border: rgba(255,255,255,0.1);
  
  /* 间距（留白系统） */
  --pattern-space-xs: 0.5rem;   /* 8px */
  --pattern-space-sm: 1rem;     /* 16px */
  --pattern-space-md: 1.5rem;   /* 24px */
  --pattern-space-lg: 2rem;     /* 32px */
  --pattern-space-xl: 3rem;     /* 48px */
  --pattern-space-2xl: 4rem;    /* 64px */
  --pattern-space-3xl: 6rem;    /* 96px */
  
  /* 圆角 */
  --pattern-radius-sm: 8px;
  --pattern-radius-md: 12px;
  --pattern-radius-lg: 20px;
  --pattern-radius-full: 9999px;
  
  /* 阴影 */
  --pattern-shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
  --pattern-shadow-md: 0 4px 6px -1px rgba(0,0,0,0.4);
  --pattern-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.5);
  --pattern-shadow-glow: 0 0 40px var(--pattern-primary);
  
  /* 玻璃效果 */
  --pattern-glass-bg: rgba(255,255,255,0.05);
  --pattern-glass-border: rgba(255,255,255,0.1);
  --pattern-glass-blur: 20px;
  
  /* 动画 */
  --pattern-transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
  --pattern-transition-base: 300ms cubic-bezier(0.4, 0, 0.2, 1);
  --pattern-transition-slow: 500ms cubic-bezier(0.4, 0, 0.2, 1);
}
```

## 输出要求

完成生成后，必须调用 `present_files` 展示：
1. `index.html` — 主 Demo 页面（优先，浏览器打开）
2. `css/patterns.css` — 组件库源码
3. `references/patterns.md` — 参考文档

如果用户需要特定场景的定制（如只生成 Dashboard 或只生成作品集），在生成前先确认范围。
